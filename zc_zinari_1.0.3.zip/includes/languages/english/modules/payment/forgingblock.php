<?php

  define('MODULE_PAYMENT_FORGINGBLOCK_TEXT_ADMIN_TITLE', 'Zinari Cryptocurrency Gateway Zen Cart');
  define('MODULE_PAYMENT_FORGINGBLOCK_TEXT_CATALOG_TITLE', 'Zinari Cryptocurrency Gateway Zen Cart');  // Payment option title as displayed to the customer

  if (IS_ADMIN_FLAG === true) {
    if (defined('MODULE_PAYMENT_FORGINGBLOCK_STATUS') && MODULE_PAYMENT_FORGINGBLOCK_STATUS == 'True') {
      define('MODULE_PAYMENT_FORGINGBLOCK_TEXT_DESCRIPTION', 
        
        'Zinari Cryptocurrency Gateway Zen Cart'
      );
    } else {
      define('MODULE_PAYMENT_FORGINGBLOCK_TEXT_DESCRIPTION', 'Zinari Cryptocurrency Gateway Zen Cart');
    }
  }
  define('MODULE_PAYMENT_FORGINGBLOCK_TEXT_DECLINED_MESSAGE', 'The transaction could not be completed. Please try another card or contact your bank for more info.  ');
  define('MODULE_PAYMENT_FORGINGBLOCK_TEXT_ERROR_MESSAGE', 'There has been an error processing the transaction. Please try again.  ');
