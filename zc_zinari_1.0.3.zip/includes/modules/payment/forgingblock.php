<?php

require_once(__DIR__.'/forgingblock/lib/Forgingblock.php');


class forgingblock extends base {
  
  var $code;
  var $moduleVersion = '1.0.3';

  var $title;

  var $description;

  var $enabled;

  protected $reportable_submit_data;
  var $transaction_id;
  var $order_nstatus; 


  /**
   * Constructor
   */
  function __construct() {
    global $order;

    $this->code = 'forgingblock';

    $this->title = MODULE_PAYMENT_FORGINGBLOCK_TEXT_CATALOG_TITLE; 
    if (IS_ADMIN_FLAG === true) {
      $this->description = MODULE_PAYMENT_FORGINGBLOCK_TEXT_DESCRIPTION;
      $this->title = MODULE_PAYMENT_FORGINGBLOCK_TEXT_ADMIN_TITLE; 
    }

    $this->enabled = (defined('MODULE_PAYMENT_FORGINGBLOCK_STATUS') && MODULE_PAYMENT_FORGINGBLOCK_STATUS == 'True');
    $this->sort_order = defined('MODULE_PAYMENT_FORGINGBLOCK_SORT_ORDER') ? MODULE_PAYMENT_FORGINGBLOCK_SORT_ORDER : null;

	
    if (null === $this->sort_order) return false;

    if (MODULE_PAYMENT_FORGINGBLOCK_STATUS == 'True' && (MODULE_PAYMENT_FORGINGBLOCK_TOKEN == '')) {
      $this->title .=  '<span class="alert"> (Not Configured)</span>';
    } elseif (MODULE_PAYMENT_FORGINGBLOCK_TESTMODE == 'Test') {
      $this->title .= '<span class="alert"> (in Testing mode)</span>';
    } 

        
    $this->gateway_currency = MODULE_PAYMENT_FORGINGBLOCK_CURRENCY;


    if (defined('MODULE_PAYMENT_FORGINGBLOCK_ORDER_STATUS_ID') && (int)MODULE_PAYMENT_FORGINGBLOCK_ORDER_STATUS_ID > 0) {
      $this->order_status = MODULE_PAYMENT_FORGINGBLOCK_ORDER_STATUS_ID;
    }

    

    if (is_object($order)) $this->update_status();

    
  }

 
  function update_status() {
    global $order, $db;

    if ($this->enabled && (int)MODULE_PAYMENT_FORGINGBLOCK_ZONE > 0 && isset($order->billing['country']['id'])) {
      $check_flag = false;
      $check = $db->Execute("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_FORGINGBLOCK_ZONE . "' and zone_country_id = '" . (int)$order->billing['country']['id'] . "' order by zone_id");
      while (!$check->EOF) {
        if ($check->fields['zone_id'] < 1) {
          $check_flag = true;
          break;
        } elseif ($check->fields['zone_id'] == $order->billing['zone_id']) {
          $check_flag = true;
          break;
        }
        $check->MoveNext();
      }

      if ($check_flag == false) {
        $this->enabled = false;
      }
    }

    // other status checks?
    if ($this->enabled) {
      // other checks here
    }
  }
	

  function javascript_validation() {
    return '';
  }
  
  function selection() {
      return array('id' => $this->code,
                   'module' => $this->title);
  }
  
	
  function pre_confirmation_check() {    
    return true;
  }
  
	
  function confirmation() {	
    return array();
  }
	
  public function after_order_create($insert_id)
  {
	  global $db, $order;
	  
	  $next_order_id = $insert_id;
	  
   	$returnURL = zen_href_link(FILENAME_CHECKOUT_SUCCESS, 'checkout_id=' . $insert_id, 'SSL');  	  
	$notifyURL = zen_href_link( 'forgingblock_notify_handler.php', '', 'SSL', false, false, true );  
			  
	$trmode = (MODULE_PAYMENT_FORGINGBLOCK_TESTMODE == 'Live') ? 'live' : 'test';  
	$forgingblockAPI = new ForgingblockAPI($trmode);	 
	  
    $forgingblockAPI->SetValue('trade', MODULE_PAYMENT_FORGINGBLOCK_TRADEID);	 
  
	$forgingblockAPI->SetValue('token', MODULE_PAYMENT_FORGINGBLOCK_TOKEN);
	$forgingblockAPI->SetValue('amount', round($order->info['total'], 2));								
	  
	$forgingblockAPI->SetValue('currency', $order->info['currency']);		
	$forgingblockAPI->SetValue('link', $returnURL);
	$forgingblockAPI->SetValue('notification', $notifyURL);
	$forgingblockAPI->SetValue('order', $next_order_id);		
	  
	$resar = $forgingblockAPI->CreateInvoice();
	  
	$Error = $forgingblockAPI->GetError();
	if ($Error) {
	 //$this->display_error_page(1,$Error);
		echo $Error;
		exit;
	}
	else {
		$payurl	= $forgingblockAPI->GetInvoiceURL();	
		header("Location: $payurl");
		exit;
	}
	  
  }

   
  function process_button() {        
    return '';
  }
  /**
   * Store the CC info to the order and process any results that come back from the payment gateway
   *
   */
  function before_process() {
	  return true;
  }

  
  function after_process() {	
    return false;
  }
  /**
   * Check to see whether module is installed
   *
   * @return boolean
   */
  function check() {
    global $db;
    // install newer switches, if relevant
    
    if (!isset($this->_check)) {
      $check_query = $db->Execute("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_FORGINGBLOCK_STATUS'");
      $this->_check = $check_query->RecordCount();
    }
    return $this->_check;
  }
  /**
   * Install the payment module and its configuration settings
   *
   */
  function install() {
    global $db, $messageStack;
    if (defined('MODULE_PAYMENT_FORGINGBLOCK_STATUS')) {
      $messageStack->add_session('Zinari Cryptocurrency Gateway Zen Cart Pages module already installed.', 'error');
      zen_redirect(zen_href_link(FILENAME_MODULES, 'set=payment&module=firstdata'));
      return 'failed';
    }
	  
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Enable Zinari Cryptocurrency Gateway Zen Cart Module', 'MODULE_PAYMENT_FORGINGBLOCK_STATUS', 'True', 'Do you want to accept  payments via ForgingBlock?', '6', '0', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
	  
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Sort order of display.', 'MODULE_PAYMENT_FORGINGBLOCK_SORT_ORDER', '0', 'Sort order of displaying payment options to the customer. Lowest is displayed first.', '6', '0', now())");
	  
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Order New Status', 'MODULE_PAYMENT_FORGINGBLOCK_ORDER_STATUS_ID', '1', 'Set the status of new orders ', '6', '0', 'zen_cfg_pull_down_order_statuses(', 'zen_get_order_status_name', now())");
	  
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Order Paid Status', 'MODULE_PAYMENT_FORGINGBLOCK_PAID_ORDER_STATUS_ID', '2', 'Set the status of paid orders ', '6', '0', 'zen_cfg_pull_down_order_statuses(', 'zen_get_order_status_name', now())");
	  
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Order Expired Status', 'MODULE_PAYMENT_FORGINGBLOCK_EXP_ORDER_STATUS_ID', '4', 'Set the status of Expired orders ', '6', '0', 'zen_cfg_pull_down_order_statuses(', 'zen_get_order_status_name', now())");	 
	  	  
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, use_function, set_function, date_added) values ('Payment Zone', 'MODULE_PAYMENT_FORGINGBLOCK_ZONE', '0', 'If a zone is selected, only enable this payment method for that zone.', '6', '2', 'zen_get_zone_class_title', 'zen_cfg_pull_down_zone_classes(', now())");
	  
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added, use_function) values ('Trade ID', 'MODULE_PAYMENT_FORGINGBLOCK_TRADEID', '', 'Trade ID assigned in your ForgingBlock', '6', '0', now(), 'zen_cfg_password_display')");
	  
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added, use_function) values ('Token', 'MODULE_PAYMENT_FORGINGBLOCK_TOKEN', '', 'Token assigned in your ForgingBlock', '6', '0', now(), 'zen_cfg_password_display')");	
	
   	$db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Environment', 'MODULE_PAYMENT_FORGINGBLOCK_TESTMODE', 'Test', 'Environment)', '6', '0', 'zen_cfg_select_option(array(\'Test\', \'Live\'), ', now())");
	  	  
  
  }
	
  /**
   * Remove the module and all its settings
   *
   */
  function remove() {
    global $db;
    $db->Execute("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
  }
	
  /**
   * Internal list of configuration keys used for configuration of the module
   *
   * @return array
   */
  function keys() {
    return array('MODULE_PAYMENT_FORGINGBLOCK_STATUS',
            'MODULE_PAYMENT_FORGINGBLOCK_SORT_ORDER',
            'MODULE_PAYMENT_FORGINGBLOCK_ORDER_STATUS_ID',
		    'MODULE_PAYMENT_FORGINGBLOCK_PAID_ORDER_STATUS_ID',				 
		    'MODULE_PAYMENT_FORGINGBLOCK_EXP_ORDER_STATUS_ID',				 				 
            'MODULE_PAYMENT_FORGINGBLOCK_ZONE',
            'MODULE_PAYMENT_FORGINGBLOCK_TRADEID',
            'MODULE_PAYMENT_FORGINGBLOCK_TOKEN',            
            'MODULE_PAYMENT_FORGINGBLOCK_TESTMODE');
  }

}



